
"language": {
                    "lengthMenu": "Mostrando _MENU_ Entradas por página",
                    "zeroRecords": "Lo sentimos, no se encuentran concidencias",
                    "info": "Mostrando Página _PAGE_ de _PAGES_ (Registros Totales _TOTAL_)",
                    "infoEmpty": "No hay entradas",
                    "infoFiltered": "(filtrar por _MAX_ total entradas)",
                    "search": "Buscar",
                    "paginate": {
                        "previous": "Anterior",
                        "next": "Siguiente"
                    }, "select": {
                        rows: " "
                    }
                }
