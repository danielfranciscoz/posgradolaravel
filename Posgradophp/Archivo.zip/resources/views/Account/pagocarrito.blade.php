@extends('layout.app')
@section('title', 'Pago de Carrito de compra')
@section('content')

@endsection